package com.nttdata.stepsdefinitions;

import com.nttdata.screens.LoginScreen;
import com.nttdata.steps.AirbnbSearchSteps;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import org.junit.Assert;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;

public class AirbnbSearchStepsDefs {


    @Steps
    AirbnbSearchSteps airbnbSearchSteps;

    @Given("que me encuentro en el login de Airbnb")
    public void que_me_encuentro_en_el_login_de_airbnb() {
        airbnbSearchSteps.clickClose();
    }
    @When("busco {string}")
    public void busco(String place) {
        airbnbSearchSteps.searchByText(place);
    }
    @Then("muestra el texto {string}")
    public void muestra_el_texto(String text) {

        Assert.assertEquals(airbnbSearchSteps.getResultText(), text);
    }








}
